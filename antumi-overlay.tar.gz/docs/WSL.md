# WSL 支持

> 状态：设计中，未实现。启动方式和连接方向在 Windows 运行器上验证过（见「已验证」），其余带「待验证」的还没有。

Windows 用户里有一类人整天在 WSL 里干活：项目放在发行版自己的目录里（`/home/<用户>/...`），Claude Code、Codex 这些 CLI 也只装在里面。Windows 上的 Antumi 只在 Windows 里找 Agent，于是一个都找不到。

## 做法：后端跑在 WSL 里，Windows 只留界面

core 和 daemon 在发行版里以 Linux 进程运行，Windows 的桌面端作为客户端连过去。git、PTY、Agent、Antumi 的 MCP 服务、登录状态、用量和历史会话都是 Linux 下的原样行为，各 Agent 的 adapter 不用改。

```
Windows                                   WSL 发行版
┌────────────────────┐                    ┌──────────────────────────────┐
│ desktop（界面）     │── RPC（WebSocket）─▶│ core ── daemon ── Agent / PTY │
│ 内置浏览器的标签页   │◀─ 浏览器 host ──────│   └─ mcp.mjs（Agent 启动）     │
└────────────────────┘                    │ ~/.antumi（任务、会话、设置）   │
                                          └──────────────────────────────┘
```

这条路现成可走，因为进程边界本来就是这样划的：core 不依赖 Electron，桌面端只是客户端，原生模块只在 daemon 里。`mcpCommand` 用 `process.execPath` 加 `ANTUMI_MCP_JS` 启动 MCP 服务（`core/src/mcp-command.ts`），换成 Linux 的 Node 不用改。

### 为什么不是「后端留在 Windows，每条命令经 `wsl.exe` 转进去」

那样要在 Windows 和 Linux 之间逐处转换路径和环境变量，git 得按项目在哪边分别处理，每个 Agent 的登录状态、用量和历史会话的位置也要单独对付。项目放在发行版自己的目录里时，Windows 的 git 经 `\\wsl.localhost` 去读又慢又不可靠，而这正是要支持的情况。

## 第一版的范围

选好发行版就能用：桌面端自己把后端装进发行版、启动它、跟着应用升级，内置浏览器可用。用户要自己准备的只有发行版里的 Node（22.13 以上）和各 Agent 的 CLI。

### Linux 后端包

发版时多一个任务（`release.yml` 的 `wsl-backend`）：在 Linux 上按 Linux 打出 `out/backend`，再由 `pack-wsl-backend.mjs` 打成 `backend-linux-x64.tar.gz`，旁边一个写着 sha256 和版本的 json。Windows 的打包任务取来放进安装包的 `resources/wsl/`。本机 `pnpm dist:win` 打的包里没有它，「后端位置」就不给选发行版。

- 里面是全部 `.mjs`、`plugins` 和 Linux 上编译的 node-pty，解开就是发行版里的一份后端。
- 在 `ubuntu-22.04` 上编：node-pty 按新 glibc 编出来的，旧 glibc 的发行版加载不了。再旧的发行版在预检时报出来。
- 只有 x64。ARM 的 Windows 上发行版是 arm64，预检时报不支持。
- 不带 Node，用发行版里的。core 用 `node:sqlite`，所以它至少要 22.13；Ubuntu 24.04 用 apt 装到的是 18，不够。

### 安装和启动

接在现有的 `ensureBackend` 上（`desktop/src/main/backend.ts`），「后端位置」选了发行版时走这一支：

1. **预检**：发行版存在、是 WSL 2、x64，登录 shell 的 PATH 上有 22.13 以上的 Node，node-pty 能加载。不满足时说清缺什么、怎么补（Node 不够新时给出升级的命令），并退回本机后端。
2. **安装**：版本目录 `~/.antumi/backend/<版本>/` 不在时，把后端包经标准输入送进发行版解开，校验 sha256，最后写就绪标记。
3. **取 PATH**：取一次发行版登录 shell 的 PATH，同 `loginShellPath` 的 Linux 分支。
4. **启动**：daemon 和 core 各由一个分离的 `wsl.exe -d <发行版> --exec env PATH=… node …` 带起来，和本机 `launch()` 的 `detached` 一样不随应用退出。Linux 进程留在 `wsl.exe` 的前台，不在发行版里再做一次后台化：有 `wsl.exe` 连着，发行版才不会被回收（见「已验证」）。
5. **替换**：core 的版本和应用不一致时，沿用 `retireCore` / `retireOldDaemon` 的规矩，daemon 只在不跑东西时才换。

桌面端读端口和令牌用 `wsl.exe --exec cat ~/.antumi/core.json`，不从 Windows 直接读 `\\wsl.localhost`：那边的 stat 会误报文件不存在。

### 连接

Antumi 自己的协议都不变，变的只是字节怎么过 Windows 和发行版之间的那道边界。

- **界面 → core**：先直接连 `127.0.0.1:<端口>`，Windows 默认会把它转进发行版。连不上时改走转发程序。
- **core → 内置浏览器**：发行版里连不到 Windows 的 `127.0.0.1`（默认网络模式下），所以必须走转发程序。

转发程序是后端包里的一个小 Node 脚本，由桌面端经 `wsl.exe` 启动，字节走这个子进程的标准输入输出，不经过网络。浏览器这一条：它在发行版的 `127.0.0.1` 上开一个端口，把连进来的连接转给桌面端主进程，主进程再连本机的浏览器 host；同时把这个端口和 host 的令牌写进发行版的 `~/.antumi/browser/host.json`，core 照原样去读、去连（`core/src/browser-service.ts`），不用改。它在标准输入关闭时退出并删掉那个文件。

core 仍然只绑 `127.0.0.1`，不为绕开 localhost 转发去监听 `0.0.0.0`。

### 路径

core 只认 Linux 路径，转换只发生在桌面端这几处 IPC（`desktop/src/main/index.ts`）：

- `antumi:pick-folder`：对话框开在 `\\wsl.localhost\<发行版>\home\<用户>`，选中的路径转成 Linux 路径再交给 core。
- `antumi:reveal-file`、`antumi:open-file`、`antumi:open-with`：Linux 路径转成 `\\wsl.localhost\<发行版>\...` 再交给系统。
- 拖进输入框的 Windows 文件：`C:\x` 转成 `/mnt/c/x`。

### 这一版没有的，和什么时候做

| 没有的 | 原因 | 什么时候做 |
| --- | --- | --- |
| 保持唤醒 | core 在发行版里，管不到 Windows 的睡眠 | 第一版确认可用后的下一个版本：改由桌面端在 Windows 上替它做 |
| 自带 Node | 定了用发行版里的，版本不够时提示用户升级 | 升级 Node 这一步挡住的用户多了再做：首次使用时下载，或放进安装包（大几十 MB） |
| 局域网里的手机直连 | WSL 默认网络下，外面连不进发行版 | 有用 WSL 的用户要用手机时。在那之前，经自己的服务器中转和 WireGuard 两种方式是 core 往外连，不受影响（待验证） |
| 同时看到 Windows 和发行版两边的数据 | 一个界面只连一个 core | 不在计划里，要改的是界面连多个后端 |

## 实现顺序

没有 Windows 机器，所以每一步都先让能验证的部分落地：

1. 验证启动方式和连接方向（`scripts/wsl-check.ps1`）。已在 Windows 运行器上做过，结果见「已验证」。
2. 调用 `wsl.exe` 的模块：列发行版、跑命令、取 PATH，按下面的规矩写，带单元测试。
3. Linux 后端包进发版流程和 Windows 安装包。
4. 预检、安装、启动、替换，接进 `ensureBackend`。
5. 「后端位置」设置和路径转换。
6. 转发程序和内置浏览器。
7. 测试版发给用 WSL 的用户，再正式发。

## 已知的限制

- **数据是两份**。Windows 的 `~/.antumi` 和发行版里的 `~/.antumi` 各有各的任务、会话和设置，「后端位置」切到哪边就看到哪边的。同时连两个后端不在这份设计里。
- **只支持 WSL 2**，一次一个发行版。
- 项目放在 `/mnt/c/...` 下也能用，但 git 和文件监听会慢，建议放在发行版自己的目录里。

## 调用 `wsl.exe` 的规矩

实现时集中在一个模块里：

- 用绝对路径的 `System32\wsl.exe`，并给它一个确定存在的 Windows 工作目录。
- 一律 `--exec`，不用 `--`：后者会把每个参数里的 `$name` 展开。
- 设 `WSL_UTF8=1`，否则 `wsl.exe` 自己的报错是 UTF-16LE。
- `--exec` 拿不到登录 shell 的 PATH，要先取一次再显式带上；取的时候用标记把输出夹起来，Ubuntu 的登录 shell 会往标准输出打提示。
- 令牌走标准输入，不进命令行参数。
- 后台检查不要把已经停掉的发行版唤醒：先看 `wsl.exe --list --running`。
- `wsl.exe --list` 的输出是 UTF-16LE 带 BOM；`docker-desktop` 这类发行版要滤掉。
- 「没问到」不等于「没有」：探测失败时保留上一次的结果，过一会儿再问。

## 已验证

用 `scripts/wsl-check.ps1` 在 GitHub 的 `windows-2025` 运行器上跑过两次（WSL 2、Ubuntu 24.04、默认的 NAT 网络），两次结果一致：

- 由分离的 `wsl.exe` 带起来的 Linux 进程，在启动它的进程退出三分钟后还在，发行版没有被回收，也没有重启过。「安装和启动」第 4 步的做法成立。
- Windows 连得上发行版里绑在 `127.0.0.1` 上的端口，用 `localhost` 也行。
- 发行版里连不上 Windows 的 `127.0.0.1`，所以内置浏览器必须走转发程序。
- 1MB 随机字节经 `wsl.exe` 的标准输入输出原样通过，没有网络时也一样。

运行器上没有桌面会话，「退出应用」是用启动它的进程退出来代替的。

## 待验证

1. 真实的 Windows 11 桌面上，退出应用、注销或睡眠后，发行版里的后端是否还在。
2. 镜像网络下两个方向的 `127.0.0.1` 是否都通。运行器上开不了镜像网络（WSL 退成没有网络），这一条只能在真机上看；届时界面连 core 也靠转发程序兜底。
3. 发行版里的 daemon 用 Unix socket、core 和各 Agent 的启动，是否和原生 Linux 上一致。
4. Node 由 nvm 之类装在登录 shell 的 PATH 里时，取 PATH 再启动是否找得到它。运行器上的 Node 在 `/usr/bin`，不经登录 shell 也找得到。
5. 经 `\\wsl.localhost` 的「用…打开」，各编辑器的表现（VS Code 会提示改用 Remote - WSL 打开）。

## 测试

GitHub 的 `windows-2025` 运行器上有 WSL 2，可以装上 Ubuntu 跑端到端测试；镜像网络和有桌面会话才有的行为仍要真机。
