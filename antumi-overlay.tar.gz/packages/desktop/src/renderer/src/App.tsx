import { AgentsView } from './components/AgentProfiles'
import { t, useLocale } from './i18n'
import { useEffect } from 'react'
import { selectTask, setSettingsOpen, useCore, useSplitPanes } from './core-store'
import { NewTaskDialog } from './components/NewTaskDialog'
import { SettingsPage } from './components/SettingsPage'
import { SourceInboxView } from './components/SourceInboxView'
import { InboxEntry } from './components/InboxEntry'
import { SourceLoginDialog } from './components/SourceLoginDialog'
import { ProjectTrustDialog } from './components/ProjectTrustDialog'
import { TaskDetail } from './components/TaskDetail'
import { TaskBoard } from './components/TaskBoard'
import { SquadsEntry } from './components/Squads'
import { SidebarTasks } from './components/SidebarTasks'
import { TaskChat } from './components/TaskChat'
import { ConversationList } from './components/ConversationList'
import { Sidebar } from './components/Sidebar'
import { TitleBar } from './components/TitleBar'
import { compactTitleBar } from './desktop-bridge'
import { COLLAPSED_NAVIGATION_WIDTH } from './sidebar-width'
import { ConversationView } from './components/ConversationView'
import { ConversationSplit } from './components/ConversationSplit'
import { ConversationDraft } from './components/ConversationDraft'
import { EnvironmentNotice } from './components/EnvironmentNotice'
import { BackendLocationNotice } from './components/BackendLocationNotice'
import { StatusBar } from './components/StatusBar'
import { UtilityPanelDock } from './components/UtilityPanelDock'
import { SearchPalette } from './components/SearchPalette'
import { WorktreeManager } from './components/WorktreeManager'
import { RoutinesView } from './components/RoutinesView'
import { RoutinesEntry } from './components/RoutinesEntry'
import { PluginPageEntries } from './components/PluginPageEntries'
import { PluginPageView } from './components/PluginPageView'
import { DiscussionView } from './components/DiscussionView'
import { DiscussionDraft } from './components/DiscussionDraft'
import { OverviewEntry } from './components/OverviewEntry'
import { OverviewView } from './components/OverviewView'
import { GuideView } from './components/GuideView'
import { SetupGuide } from './components/SetupGuide'
import { useFirstRunSetup } from './setup-controller'
import { WindowBrand } from './components/WindowBrand'
import { ErrorToast } from './components/ErrorToast'
import { TaskLaunchDialog } from './components/TaskLaunchDialog'
import { usePreferences } from './preferences'
import { usePortPolling } from './port-state'
import { useUpdateFeed } from './update-state'
import { useBackendLocationFeed } from './backend-location-state'
import { AppPet } from './components/AppPet'
import { recordingPanelShortcut, usePanelShortcuts } from './panel-shortcuts'

// Esc goes from a task back to the board, unless it is meant for what has the focus:
// typing (the composer interrupts the agent with it), a terminal, or a menu or dialog, which close first.
function leavesTask(event: KeyboardEvent): boolean {
  const s = useCore.getState()
  if (event.defaultPrevented || s.section !== 'tasks' || s.selectedId === null) return false
  if (s.settingsOpen || s.newTaskOpen || s.taskLaunchId || s.worktreesOpen || s.routinesOpen || s.overviewOpen || s.inboxOpen) return false
  const typing = event.target instanceof Element && event.target.closest('input, textarea, select, [contenteditable="true"], .xterm, [role="menu"], dialog')
  return !typing && !document.querySelector('dialog[open]')
}

export function App() {
  usePanelShortcuts()
  useLocale((state) => state.locale)
  usePortPolling()
  useUpdateFeed()
  useBackendLocationFeed()
  const selectedId = useCore((s) => s.selectedId)
  const section = useCore((s) => s.section)
  const selectedConversationId = useCore((s) => s.selectedConversationId)
  const splitPanes = useSplitPanes()
  const conversationDraft = useCore((s) => s.conversationDraft)
  const conversationDraftFrom = useCore((s) => s.conversationDraftFrom)
  const draftProfileId = useCore((s) => s.draftProfileId)
  const selectedDiscussionId = useCore((s) => s.selectedDiscussionId)
  const pluginPage = useCore((s) => s.pluginPage)
  const draftMode = useCore((s) => s.conversationDraftMode)
  const discussionDraftFrom = useCore((s) => s.discussionDraftFrom)
  const view = useCore((s) => s.view)
  const error = useCore((s) => s.error)
  const newTaskOpen = useCore((s) => s.newTaskOpen)
  const taskLaunchId = useCore((s) => s.taskLaunchId)
  const settingsOpen = useCore((s) => s.settingsOpen)
  const gitPanelOpen = useCore((s) => s.gitPanelOpen)
  const gitMaximized = useCore((s) => s.gitMaximized)
  const worktreesOpen = useCore((s) => s.worktreesOpen)
  const routinesOpen = useCore((s) => s.routinesOpen)
  const overviewOpen = useCore((s) => s.overviewOpen)
  const guideOpen = useCore((s) => s.guideOpen)
  useFirstRunSetup()
  const inboxOpen = useCore((s) => s.inboxOpen)
  const loginOpen = useCore((s) => s.login !== null)
  const terminalPanelOpen = useCore((s) => s.terminalPanelOpen)
  const terminalMaximized = useCore((s) => s.terminalMaximized)
  const browserPanelOpen = useCore((s) => s.browserPanelOpen)
  const browserMaximized = useCore((s) => s.browserMaximized)
  const portsPanelOpen = useCore((s) => s.portsPanelOpen)
  const portsMaximized = useCore((s) => s.portsMaximized)
  const filesPanelOpen = useCore((s) => s.filesPanelOpen)
  const filesMaximized = useCore((s) => s.filesMaximized)
  const search = useCore((s) => s.search)
  const utilityPanelOrder = useCore((s) => s.utilityPanelOrder)
  const menuCollapsed = usePreferences((s) => s.sidebarMenuCollapsed)
  const maximizedUtility = browserPanelOpen && browserMaximized
    ? 'browser'
    : terminalPanelOpen && terminalMaximized
      ? 'terminal'
      : portsPanelOpen && portsMaximized
        ? 'ports'
        : filesPanelOpen && filesMaximized
          ? 'files'
          : gitPanelOpen && gitMaximized
            ? 'git'
            : undefined

  // With the menu collapsed to icons, the title bar, the icons and the status bar frame the pages,
  // which sit on a card below the title bar.
  const framed = menuCollapsed && !settingsOpen && !maximizedUtility
  useEffect(() => { compactTitleBar(framed) }, [framed])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.defaultPrevented || event.isComposing || event.keyCode === 229 || event.repeat || recordingPanelShortcut()) return
      if (event.key === 'Escape' && useCore.getState().settingsOpen && !useCore.getState().newTaskOpen) {
        setSettingsOpen(false)
      } else if (event.key === 'Escape' && leavesTask(event)) {
        selectTask(null)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [])

  // Files dragged anywhere but a drop target are swallowed here rather than opened by the window.
  useEffect(() => {
    const swallow = (event: DragEvent) => {
      if (event.dataTransfer?.types.includes('Files')) {
        event.preventDefault()
      }
    }
    window.addEventListener('dragover', swallow)
    window.addEventListener('drop', swallow)
    return () => {
      window.removeEventListener('dragover', swallow)
      window.removeEventListener('drop', swallow)
    }
  }, [])

  return (
    <div className="app" data-framed={framed || undefined} style={{ '--sidebar-navigation-width': `${menuCollapsed ? COLLAPSED_NAVIGATION_WIDTH : 0}px` }}>
      <main className="workspace" data-utility-maximized={maximizedUtility}>
        {settingsOpen ? (
          <SettingsPage />
        ) : (
          <>
            <Sidebar>
              {!menuCollapsed && <>
                <OverviewEntry />
                <InboxEntry />
                <RoutinesEntry />
                <PluginPageEntries />
                <SquadsEntry />
              </>}
              <EnvironmentNotice />
              <BackendLocationNotice />
              {!menuCollapsed && <SidebarTasks />}
              <ConversationList />
            </Sidebar>
            {overviewOpen ? (
              guideOpen ? <GuideView /> : <OverviewView />
            ) : inboxOpen ? (
              <SourceInboxView />
            ) : worktreesOpen ? (
              <WorktreeManager />
            ) : routinesOpen ? (
              <RoutinesView />
            ) : section === 'squads' ? (
              <AgentsView />
            ) : section === 'plugin' ? (
              pluginPage ? <PluginPageView key={`${pluginPage.plugin}/${pluginPage.page}`} plugin={pluginPage.plugin} page={pluginPage.page} /> :
                <section className="detail-empty"><div className="detail-empty-body">{t('App.chooseOrCreateAConversation')}</div></section>
            ) : section === 'discussions' ? (
              selectedDiscussionId ? <DiscussionView key={selectedDiscussionId} id={selectedDiscussionId} /> :
                <section className="detail-empty"><div className="detail-empty-body">{t('App.chooseOrCreateAGroupChat')}</div></section>
            ) : section === 'conversations' ? (
              splitPanes && selectedConversationId ? <ConversationSplit panes={splitPanes} active={selectedConversationId} /> :
              selectedConversationId ? <ConversationView key={selectedConversationId} id={selectedConversationId} /> :
                conversationDraft && draftMode === 'group' ? <DiscussionDraft key={discussionDraftFrom?.discussion.id ?? 'blank'} from={discussionDraftFrom?.discussion ?? null} /> :
                conversationDraft ? <ConversationDraft key={draftProfileId ?? conversationDraftFrom?.key ?? 'blank'} /> :
                <section className="detail-empty"><div className="detail-empty-body">{t('App.chooseOrCreateAConversation')}</div></section>
            ) : selectedId && view === 'chat' ? (
              <TaskChat key={selectedId} taskId={selectedId} />
            ) : selectedId ? (
              <TaskDetail key={selectedId} taskId={selectedId} />
            ) : (
              <TaskBoard />
            )}
          </>
        )}
        {(portsPanelOpen || browserPanelOpen || terminalPanelOpen || filesPanelOpen || gitPanelOpen) && (
          <UtilityPanelDock
            open={{ browser: browserPanelOpen, terminal: terminalPanelOpen, ports: portsPanelOpen, files: filesPanelOpen, git: gitPanelOpen }}
            maximized={maximizedUtility}
            order={utilityPanelOrder}
          />
        )}
      </main>
      <SetupGuide />
      {/* After the workspace: where drag regions overlap, the later one wins, and the sidebar and
          pane headers under it are drag regions. */}
      {framed && <TitleBar />}
      {!settingsOpen && !maximizedUtility && <WindowBrand />}
      <StatusBar panelsInTitleBar={framed} />
      {search && <SearchPalette initial={search} />}
      {newTaskOpen && <NewTaskDialog />}
      {taskLaunchId && <TaskLaunchDialog key={taskLaunchId} taskId={taskLaunchId} />}
      {loginOpen && <SourceLoginDialog />}
      <ProjectTrustDialog />
      {error && !newTaskOpen && !taskLaunchId && <ErrorToast message={error} />}
      <AppPet />
    </div>
  )
}
